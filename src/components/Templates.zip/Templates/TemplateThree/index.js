import React from "react";

import styled from "styled-components";
import images from "./assets";
import {Line} from 'react-chartjs-2';

export default () => {
  const Container = styled.div`
    height: auto;
    width : 100%;
    background-color:#FAFBFC;
    margin-left: auto;
    margin-right: auto;
  `;
  const MainSide = styled.div`
  `;
const Heading = styled.h4`
    font-size:17px;
    color: ##1E1950;
    padding : 10px 0
`;
const PersonalBox = styled.div`
    background-color: white;
    box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    -webkit-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    -moz-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    border-radius: 10px;
    padding : 25px;

`;

const ProfileImage = styled.img`
    height : 145px;
    border-radius : 50%;
    width: 145px;
    box-shadow: 0px 10px 5px -7px rgba(0,0,0,0.1);
    -webkit-box-shadow:0px 10px 5px -7px rgba(0,0,0,0.1);
    -moz-box-shadow:0px 10px 5px -7px rgba(0,0,0,0.1);
`;

const Title = styled.h4`
    font-size : 17px;
    font-weight: bold;
    text-align : center;
    color:#1E1950;
    text-transform : uppercase;

`;
const TitleOrange = styled.h5`
    font-size : 14px;
    font-weight : 500;
    text-align : center ;
    color : #EC642A;
    text-transform : uppercase;
    letter-spacing : 3px;
`;
const ContentDetails = styled.p`
    font-size : 15px;
    font-weight : 500;
    text-align : center ;
    color: #5B3F67;
    line-height : 20px;
    margin : 0;
    padding-bottom : 10px;

`;
const Projects = styled.div`
    background-color : #0B1D79;
    color : white !important ; 
    padding : 15px; 
    text-align : center;
    border-radius:10px;
    margin: 20px 0;
    h4{
        color : white;
        font-size : 21px;
    }
    h5{
        color: white;
    }
   
`;
const SocialBox = styled.div`
background-color: white;
box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
-webkit-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
-moz-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
border-radius: 10px;
padding : 25px;
`;
const Icon = styled.img`
   
`;

const NameImg = styled.div`
    display : flex ; 
    flex-wrap : wrap ;
    align-items:center;
    margin-bottom : 20px;
    p{
        margin-left : 20px;
        margin-bottom : 0 ;
    }
`;
const state = {
    labels: ['Job Title', 'Job Title', 'Job Title'],
    datasets: [
      {
        label: '',
        fill: false,
        lineTension: 0.5,
        backgroundColor: 'rgba(75,192,192,1)',
        borderColor: 'rgba(0,0,0,1)',
        borderWidth: 2,
        data: [65, 59, 80]
      }
    ]
  }
const Label = styled.h4`
    font-size : 16px;
    font-weight : 500;
    color : #5B3F67;
 `;
 const DetailBox = styled.div`
    display : flex; 
    flex-wrap: wrap ;
    
    
 `;
 const ContentMain = styled.div`
    margin-left : 40px;

    p{
        text-align : left;
    }

    h4{
        text-align : left ;
        position:relative ; 
        :before{
            content : "";
            position: absolute;
            height : 15px;
            width : 15px ;
            border-radius : 50%;
            background-color : white;
            border : 1px solid black;
            left : -25px;
            top : 3px ;

        }
    }
    
 `;
 const TitleSpan = styled.span`
        font-size : 15px;
        font-weight : 500 ;
        padding : 5px 15px;
        border-radius : 5px ;
        margin-left : 50px;

 `;

  return (
    <Container>
      <div className="my-row">
        <div className="col-4">
            <MainSide>
            <Heading>
            personal information
            </Heading>
            <PersonalBox>
                <div class="d-flex justify-content-center">
                    <ProfileImage src={images.profileimg}></ProfileImage>
                </div>
                <Title className="pt-5">ANA JONES</Title>
        <TitleOrange>
            DEsigner
        </TitleOrange>
        <ContentDetails>
        Ana is a graphic designer who works in a web designing company. They often ask for quick designs and she would like to have the help of ready-made graphics, which you can later modify  to fit
 your needs.

        </ContentDetails>
                </PersonalBox>
            <div class="d-flex justify-content-between flex-wrap">
                <Projects>
                <Title>+20</Title>
                <TitleOrange>
                    Projects
                </TitleOrange>
            </Projects>
                <Projects style={{backgroundColor : "#EC642A"}}>
                <Title>+30</Title>
                <TitleOrange>
                    Customer
                </TitleOrange>
            </Projects>
                <Projects style={{backgroundColor : "#B59C7A" }}>
                <Title>4 Years</Title>
                <TitleOrange>
                    Experience
                </TitleOrange>
            </Projects>
            </div>
            <SocialBox>
            <NameImg>
                <Icon src={images.email}></Icon>
                <ContentDetails>Email Address</ContentDetails>
            </NameImg>
            <NameImg>
                <Icon src={images.phone}></Icon>
                <ContentDetails>Phone Number</ContentDetails>
            </NameImg>
            <NameImg>
                <Icon src={images.location}></Icon>
                <ContentDetails>Home Address</ContentDetails>
            </NameImg>
            <NameImg>
                <Icon src={images.ln}></Icon>
                <ContentDetails>Linkedin.com/in/Username</ContentDetails>
            </NameImg>
            <NameImg>
                <Icon src={images.drible}></Icon>
                <ContentDetails>Dribbble.com/Username</ContentDetails>
            </NameImg>
            <NameImg>
                <Icon src={images.behance}></Icon>
                <ContentDetails>Behance.net/Username</ContentDetails>
            </NameImg>
            </SocialBox>
            <Heading>
                Professional Goals
            </Heading>
            <PersonalBox>
            <Line
          data={state}
          options={{
            title:{
              display:false,
              text:'Average Rainfall per month',
              fontSize:20
            },
            legend:{
              display:false,
              position:'right'
            }
          }}
        />
      </PersonalBox>
            </MainSide>
           </div>
           <div class="col-8">
          <MainSide>
              <Heading>
                  Experience
              </Heading>
              <PersonalBox>
                  <DetailBox className="mb-5">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                Job title - company name
                <TitleSpan className="orange-span">
                    Current Job
                </TitleSpan>
                </Title>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-5">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                Job title - company name
                <TitleSpan className="blue-span">
                    9 Months
                </TitleSpan>
                </Title>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
                                <DetailBox>
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                Job title - company name
                <TitleSpan className="blue-span">
                   1 Year
                </TitleSpan>
                </Title>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
              </PersonalBox>
              <Heading>
                  Education
              </Heading>
              <PersonalBox>
                  <DetailBox className="mb-5">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                title  of Formation - School name
                <TitleSpan className="orange-span">
                    Current Formation
                </TitleSpan>
                </Title>
               
                <ContentDetails>
                Formation Degree
                </ContentDetails>
          
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-5">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                title  of Formation - School name
                <TitleSpan className="blue-span">
                   1 Year
                </TitleSpan>
                </Title>
               
                <ContentDetails>
               Formation Degree
                </ContentDetails>
         
                </ContentMain>
                </DetailBox>
               <DetailBox>
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <Title>
                title  of Formation - School name
                <TitleSpan className="blue-span">
                   1 Year
                </TitleSpan>
                </Title>
               
                <ContentDetails>
               Formation Degree
                </ContentDetails>
         
                </ContentMain>
                                </DetailBox>
                               
              </PersonalBox>
              <Heading>
                  Software Skills
              </Heading>
              <PersonalBox>
                  <div className="my-row">
                      <div className="col-6">
                          <Label>
                              Sketch App
                          </Label>
                          <input type="range" min="1" max="100" value="80" className="slider" id="myRange" />
                          <Label>
                             Photoshop
                          </Label>
                          <input type="range" min="1" max="100" value="50" className="slider" id="myRange" />
                          <Label>
                              Invision
                          </Label>
                          <input type="range" min="1" max="100" value="30" className="slider" id="myRange" />

                      </div>
                      <div className="col-6">
                          <Label>
                              Adobe XD
                          </Label>
                          <input type="range" min="1" max="100" value="80" className="slider" id="myRange" />
                          <Label>
                             Illustrator
                          </Label>
                          <input type="range" min="1" max="100" value="50" className="slider" id="myRange" />
                          <Label>
                              Design System
                          </Label>
                          <input type="range" min="1" max="100" value="30" className="slider" id="myRange" />

                      </div>
                  </div>
              </PersonalBox>
              <Heading>
                  Software Skills
              </Heading>
              <PersonalBox>
                  <div className="my-row">
                      <div className="col-3">
                          <div className="d-flex align-items-center flex-wrap">
                          <img src={images.travel} alt="" />
                          <ContentDetails className="pl-3">Travel</ContentDetails>
                          </div>
                      </div>
                      <div className="col-3">
                          <div className="d-flex align-items-center flex-wrap">
                          <img src={images.reading} alt="" />
                          <ContentDetails className="pl-3">Reading</ContentDetails>
                          </div>
                      </div>
                      <div className="col-3">
                          <div className="d-flex align-items-center flex-wrap">
                          <img src={images.videogames} alt="" />
                          <ContentDetails className="pl-3">Video Games</ContentDetails>
                          </div>
                      </div>
                      <div className="col-3">
                          <div className="d-flex align-items-center flex-wrap">
                          <img src={images.sports} alt="" />
                          <ContentDetails className="pl-3">Sports</ContentDetails>
                          </div>
                      </div>
                  </div>
              </PersonalBox>
          </MainSide>
           </div>
        
      </div>
    </Container>
  );
};

