import email from "./email.png";
import phone from "./phone.png";
import profileimg from "./profileimg.png";
import graduation from "./graduation.png";
import heart from "./heart.png";
import projects from "./projects.png";
import global from "./global.png";
import setting from  "./settings.png";
import leadership from "./leadership.png";
import behance from "./behance.png";
import ln from "./in.png";
import twitter from "./twitter.png";

export default {
  email,
  phone,
  profileimg,
  graduation,
  heart,
  projects,
  global,
  setting,
  leadership,
  behance,
  ln,
  twitter,


};
