import React from "react";
import styled from "styled-components";
import images from "./assets";
export default () => {
    const Container = styled.div`
      margin-left: auto;
      margin-right: auto;
      background-color : #9b91ff0a;
      padding : 40px;
    `;
    const MainBox = styled.div`
        background-color : white;
        padding : 40px;
    `;
  const ProfileDetail = styled.div`
        display : flex;
        justify-content : space-between ; 

  `;
  const ProfileName = styled.h1`
    font-size : 45px;
    font-weight: normal ;
    color :#1E1950;
    text-transform : uppercase;
    border-bottom : 6px solid #D8E0F2;
  `;
  const ContentDetail = styled.p`
    font-size : 12px;
    color : #D8E0F2;
    margin : 0;
    padding-left : 10px;
  `;

  const ProfileDetails = styled.div``;
  const ImageSide = styled.div`

        img{
            height:114px;
            width:114px;
            border-radius : 50%;
            box-shadow: 0px 9px 5px 0px rgba(216,224,242,0.12);
-webkit-box-shadow: 0px 9px 5px 0px rgba(216,224,242,0.12);
-moz-box-shadow: 0px 9px 5px 0px rgba(216,224,242,0.12);
        }
  `;
  const DevelopmentTitle = styled.div`
        background-color :#D8E0F233;
        padding : 25px;
       

        h2{
            font-size : 35px;
            font-weight : 500;
            color : #1E1950;
            text-align : center;
            
        }
  `;
  const Heading = styled.h3`
        font-size :18px;
        font-weight : 500;
        color : #1E1950;
        position : relative;

  `;
  const Title = styled.h4`
        font-size : 14px;
        font-weight : 500;
        
        color :#3A3095;
  `;
  const Description = styled.div`
        margin-bottom : 30px;
        width : 75%;

  `;
  const ProjectBox = styled.div`
        background-color : white;
        box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
-webkit-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
-moz-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
padding : 30px 15px;
border-radius : 10px;
    `;

const ProjectDescription = styled.p`
        font-size : 15px;
        color : #8C8B9140;
        margin-left : 25px;

`;
const ProjectsMain = styled.div`

        img{
            margin-top : 50px;  
        }
`;
const ExperienceDivider = styled.div`
        background-color : #F0F3F9;
        height : 1px;
        width : 100%;
        margin: 30px 0;
        position:relative;

        :before{
            content : "" ;
            position : absolute ; 
            height : 10px;
            width : 10px;
            border-radius : 50%;
            background-color : #FF8A23;
            top : -5px;
            left : 0;

        }
        :after{
            content : "" ;
            position : absolute ; 
            height : 10px;
            width : 10px;
            border-radius : 50%;
            background-color : #FF8A23;
            top : -5px;
            left : 50%;
            
        }
`;
const Footer = styled.div`
        background-color : #F0F3F9;
        padding: 50px 0;
        border-bottom: 31px solid #1E1950;

        p{
            color : #1E1950;
            text-align : center;
        }
`;
const SocialFooter = styled.div`
        display : flex;
        justify-content : center ;
      
    `;

    return (
      <Container>
     <MainBox>
         <ProfileDetail>
            <ProfileDetails>
        <ProfileName>
            ANA jOnes
        </ProfileName>
        <div className="d-flex align-items-center">
        <img src={images.email} alt="" />
        <ContentDetail>
          
            Example@email.com
        </ContentDetail>
        </div>
        <div className="d-flex align-items-center">
        <img src={images.phone} alt="" />
        <ContentDetail>
          
        +92 111 333 4532
        </ContentDetail>
        </div>
        </ProfileDetails>
        <ImageSide>
            <img src={images.profileimg} alt="" />
            <ContentDetail className="orange-color text-center">
                DEVELOPER
            </ContentDetail>
        </ImageSide>
         </ProfileDetail>
        
     </MainBox>
     <DevelopmentTitle>
             <h2>Development and design of web applications <br />
for startups and large companies</h2>
         </DevelopmentTitle>
         <MainBox>
             <div className="my-row">
                 <div className="col-4">
                     <img src={images.graduation} alt="" />

                    <Heading>
                    Skills
                    </Heading>
                    <div className="d-flex flex-wrap ">
                        <Description>
                            <Title>
                            Object programming & frameworks
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Php, Symfony, Laravel, Silex, ...
                            </Title>
                        </Description>
                        <Heading>+5 <span className="orange-color">Years</span></Heading>
                    </div>
                    <div className="d-flex flex-wrap ">
                        <Description>
                            <Title>
                            Design Integration
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Style and tools, JS frameworks
                            </Title>
                        </Description>
                        <Heading>+3 <span className="orange-color">Years</span></Heading>
                    </div>
                    <div className="d-flex flex-wrap ">
                        <Description>
                            <Title>
                            Linux
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Scripting, Servers management and
                            protocols, Automation
                            </Title>
                        </Description>
                        <Heading>+1 <span className="orange-color">Years</span></Heading>
                    </div>
                 </div>
                 <div className="col-4">
                     <img src={images.heart} alt="" />

                    <Heading>
                    Intrests
                    </Heading>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                            Scripting Languages
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Php, Js, Bash, Python
                            </Title>
                        </Description>
                    </div>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                            Hacking
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Linux, Crawlers, Bots, Network
                            </Title>
                        </Description>
                    </div>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                            Tech
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Hardware Solutions, Software Solutions
                            </Title>
                        </Description>
                    </div>
                 </div>
                 <div className="col-4">
                     <img src={images.heart} alt="" />

                    <Heading>
                    Hobbies
                    </Heading>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                           Outdoors
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Hicking, Traveliing, Swimming
                            </Title>
                        </Description>
                    </div>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                            Gaming
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Snow Bros, PUBG, Clash of Clans
                            </Title>
                        </Description>
                    </div>
                    <div className="d-flex flex-wrap justify-content-between">
                        <Description>
                            <Title>
                            Writing
                            </Title>
                            <Title style={{color: "#8C8B9140"}}>
                            Novels, Stories, Books, Plays
                            </Title>
                        </Description>
                    </div>
                 </div>
             </div>
             <ProjectsMain>
             <div className="my-row">
                 <div className="col-6">
                 <img src={images.projects} alt="" />

                <Heading>
                Projects
                </Heading>
                <ProjectBox>
                    <div className="d-flex">
                    <Heading>
                        60 <span className="plus">+</span>
                    </Heading>
                    <ProjectDescription>
                    Adapting and creating solutions for customer's needs
                    </ProjectDescription>
                    </div>
                </ProjectBox>
                 </div>
                 <div className="col-6">
                 <img src={images.global} alt="" />

                <Heading>
                Web
                </Heading>
                <ProjectBox>
                    <div className="d-flex">
                    <Heading>
                        50 <span className="plus">%</span>
                    </Heading>
                    <ProjectDescription>
                    Applications development integrating third-party
services and mobile clients
                    </ProjectDescription>
                    </div>
                </ProjectBox>
                 </div>
                 <div className="col-6">
                 <img src={images.setting} alt="" />

                <Heading>
               Technical Solution
                </Heading>
                <ProjectBox>
                    <div className="d-flex">
                    <Heading>
                        30 <span className="plus">%</span>
                    </Heading>
                    <ProjectDescription>
                    Such as web services, scripts, configurations
                    </ProjectDescription>
                    </div>
                </ProjectBox>
                 </div>
                 <div className="col-6">
                 <img src={images.leadership} alt="" />

                <Heading>
               Leading
                </Heading>
                <ProjectBox>
                    <div className="d-flex">
                    <Heading>
                        20 <span className="plus">%</span>
                    </Heading>
                    <ProjectDescription>
                    Such as web services, scripts, configurations
                    </ProjectDescription>
                    </div>
                </ProjectBox>
                 </div>
             </div>
             </ProjectsMain>
           
         </MainBox>
         <MainBox>
       <div className="my-row">
         
           <div className="col-6 p-0">
         
           <Heading>
                 Experiences
             </Heading>
             <ExperienceDivider>
               
               </ExperienceDivider>
           <div className="my-row">
               <div className="col-6 p-0">
               <Title>
             Lead developer
@geronimo
             </Title>
             <Title style={{color: "#8C8B9140"}}>
             Today - apr. 2016
             </Title>
               </div>
               <div className="col-6 p-0">
               <Title>
            Freelancer
             </Title>
             <Title style={{color: "#8C8B9140"}}>
             Apr. 2016 - Sep. 2015
             </Title>
               </div>
           </div>
           </div>
           <div className="col-6 p-0">
               <Heading>
                   Education
               </Heading>
               <ExperienceDivider>
               
               </ExperienceDivider>
               <div className="my-row">
               <div className="col-6 p-0">
               <Title>
               Title  of Formation
School Name
             </Title>
             <Title style={{color: "#8C8B9140"}}>
             2015 - 2013
             </Title>
               </div>
               <div className="col-6 p-0">
               <Title>
               Title  of Formation
School Name
             </Title>
             <Title style={{color: "#8C8B9140"}}>
             2015 - 2013 
             </Title>
               </div>
           </div>
           </div>
       </div>
         </MainBox>
         <Footer>
             <div className="my-row">
                 <div className="col-4">
                     <SocialFooter>
                    <img src={images.behance} alt="" />
                    </SocialFooter>
                    <ContentDetail>www.behance.net/aliraza37</ContentDetail>

                   
                 </div>
                 <div className="col-4">
                 <SocialFooter>
                    <img src={images.ln} alt="" />

                    </SocialFooter>
                    <ContentDetail>www.linkedin.com/aliraza</ContentDetail>

                 </div>
                 <div className="col-4">
                 <SocialFooter>
                    <img src={images.twitter} alt="" />

                    </SocialFooter>
                    <ContentDetail>www.linkedin.com/aliraza</ContentDetail>

                 </div>
             </div>
         </Footer>
      </Container>
    );
  };
  