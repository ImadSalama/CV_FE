import address from "./address.png";
import call from "./call.png";
import dob from "./dob.png";
import mail from "./mail.png";
import name from "./name.png";
import website from "./website.png";

export default {
  address,
  call,
  dob,
  mail,
  name,
  website,
};
