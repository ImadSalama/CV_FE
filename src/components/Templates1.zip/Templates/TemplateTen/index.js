import React from "react";
import styled from "styled-components";
import images from "./assets";
import "react-circular-progressbar/dist/styles.css";
import { CircularProgressbar } from "react-circular-progressbar";
import ProgressBar from "@ramonak/react-progress-bar";

export default () => {
  const Container = styled.div`
    margin-left: auto;
    margin-right: auto;
    background-color: white;
    position: relative;
  `;
  const ProfileBox = styled.div`
    background-color: #a8c8d2;
    padding: 80px;
  `;
  const ProfileName = styled.h1`
    color: #443c3c;
    font-size: 3em;
    font-weight: normal;
    width: 25%;
    text-transform: uppercase;
    span {
      font-weight: bold;
    }
  `;
  const ProfileDesg = styled.h4`
    font-size: 1.5em;
    color: #47403b;
    text-transform: uppercase;
  `;
  const Content = styled.p`
    font-size: 1em;
    color: #636567;
    margin: 0;
    span {
      font-weight: bold;
    }
  `;
  const ContactDetails = styled.div`
    display: flex;
    margin: 15px 0;

    img {
      height: 25px;
      width: 25px;
      object-fit: contain;
    }
    p {
      border-left: 1px solid white;
      padding-left: 15px;
      margin-left: 10px;
    }
  `;
  const ContactBox = styled.div`
    border-top: 2px solid #5d808c;
    border-bottom: 2px solid #5d808c;
    margin-top: 20px;
  `;
  const WhiteBox = styled.div`
    background: #f0edf1;
    padding: 20px 80px;
  `;
  const Box = styled.div`
    border-radius: 19px;
    background-color: #d9e1e7;
    padding: 25px;
    margin: 10px 0;
  `;
  const Title = styled.h3`
    font-size: 1.5em;
    font-family: "Montserrat";
    color: #5d808c;
    text-transform: uppercase;
    text-align: left;
    font-weight: bold;
    position: relative;
    :after {
      content: "";
      height: 2px;
      width: 85%;
      position: absolute;
      right: 0;
      top: 20px;
      background-color: #5d808c;
    }
  `;
  const Experience = styled.div`
    margin-top: 20px;
  `;
  const TitleSmall = styled.h4`
    font-size: 1em;
    font-weight: bold;
    color: #636567;
    margin-top: 20px;
  `;
  const NumberBullet = styled.li`
    margin-left: 15px;
    list-style: decimal;
    color: #636567;
    font-size: 0.8em;
  `;
  const SkillsBox = styled.div`
    display: flex;
    align-items: center;
    span {
      padding: 0px 20px 0 0;
    }
    span:last-child {
      padding: 0 20px;
    }
  `;
  const SkillsBar = styled.div``;
  return (
    <Container>
      <ProfileBox>
        <div className="my-row">
          <div className="col-4">
            <ProfileName>
              ANA <span>Jones</span>
            </ProfileName>
            <ProfileDesg>graphic designer</ProfileDesg>
          </div>
          <div className="col-8">
            <Content>
              <span>Ana Jones</span>
              <br />
              Ana is a graphic designer and he have experince in different
              catagories iduntut labore et dolore magna aliqua. Ut enim adminim
              veniam, quisnost exercitation ullamco laboris nisi utaliquip exea
              commodo consequat. Duisaute iruredolor in repre henderit in
              voluptate velitesse cillum dolore eu fugiat nulla pariatur.
              Excepteursint occaecat cupidatat non proident, suntin culpa
              quiofficia deserunt mollit animidest lab orum. Sed ut perspiciatis
              unde omnis iste natus error sit voluptatem accusantiumdol oremque
              laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore
              veritatis et quasi architecto beatae vitae dicta sunt explicabo.
            </Content>
            <ContactBox>
              <div className="my-row">
                <div className="col-6 p-0">
                  <ContactDetails>
                    <img src={images.name} alt="" />
                    <Content>Ana Jones</Content>
                  </ContactDetails>
                  <ContactDetails>
                    <img src={images.dob} alt="" />
                    <Content>June 1, 1985</Content>
                  </ContactDetails>
                  <ContactDetails>
                    <img src={images.address} alt="" />
                    <Content>108 W Skillet Ave, Dayton, 50530</Content>
                  </ContactDetails>
                </div>
                <div className="col-6 p-0">
                  <ContactDetails>
                    <img src={images.call} alt="" />
                    <Content>(603) 123 456 789</Content>
                  </ContactDetails>
                  <ContactDetails>
                    <img src={images.mail} alt="" />
                    <Content>ana@gmail.com</Content>
                  </ContactDetails>
                  <ContactDetails>
                    <img src={images.website} alt="" />
                    <Content>your.website.com</Content>
                  </ContactDetails>
                </div>
              </div>
            </ContactBox>
          </div>
        </div>
      </ProfileBox>
      <WhiteBox>
        <Box>
          <Title>Experience</Title>
          <Experience>
            <div className="my-row">
              <div className="col-4 p-0">
                <TitleSmall>Company Name</TitleSmall>
                <Content>Graphic Designer | 2014 - Present</Content>
                <TitleSmall>Major Job Responsibilities:</TitleSmall>
                <ul>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                </ul>
              </div>
              <div className="col-4 p-0">
                <TitleSmall>Company Name</TitleSmall>
                <Content>Graphic Designer | 2014 - Present</Content>
                <TitleSmall>Major Job Responsibilities:</TitleSmall>
                <ul>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                </ul>
              </div>
              <div className="col-4 p-0">
                <TitleSmall>Company Name</TitleSmall>
                <Content>Graphic Designer | 2014 - Present</Content>
                <TitleSmall>Major Job Responsibilities:</TitleSmall>
                <ul>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                  <NumberBullet>Your Main Work</NumberBullet>
                </ul>
              </div>
            </div>
          </Experience>
        </Box>
      </WhiteBox>
      <WhiteBox>
        <Box>
          <Title>Education</Title>
          <Experience>
            <div className="my-row">
              <div className="col-4 p-0">
                <TitleSmall>Post Graduate in Graphic Design</TitleSmall>
                <Content>University Name</Content>
                <Content>2010 - 2014 | GPA 3.5</Content>
              </div>
              <div className="col-4 p-0">
                <TitleSmall>Under Graduate in Graphic Design</TitleSmall>
                <Content>College Name</Content>
                <Content>2010 - 2014 | GPA 3.5</Content>
              </div>
              <div className="col-4 p-0">
                <TitleSmall>High School in Multimedia</TitleSmall>
                <Content>School Name</Content>
                <Content>2010 - 2014 | GPA 3.5</Content>
              </div>
            </div>
          </Experience>
        </Box>
      </WhiteBox>
      <WhiteBox>
        <Box>
          <Title>Skills</Title>
          <Experience>
            <div className="my-row">
              <div className="col-4 p-0">
                <SkillsBar></SkillsBar>
              </div>
              <div className="col-4 p-0"></div>
              <div className="col-4 p-0"></div>
            </div>
          </Experience>
        </Box>
      </WhiteBox>
    </Container>
  );
};
