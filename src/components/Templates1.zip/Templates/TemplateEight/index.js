import React from "react";
import styled from "styled-components";
import images from "./assets";
import "react-circular-progressbar/dist/styles.css";
import ProgressBar from "@ramonak/react-progress-bar";

export default () => {
  const Container = styled.div`
    margin-left: auto;
    margin-right: auto;
    background-color: white;
    position: relative;
  `;
  const MainSec = styled.div`
    background: url(${images.bg}) no-repeat;
    background-size: contain;
    width: 100%;
    padding: 150px 0 30px 0;
  `;
  const ProfileName = styled.h2`
    font-size: 1.37em;
    font-family: "Montserrat";
    color: rgb(255, 255, 255);
    line-height: 1.182;
    text-align: center;
    text-transform: uppercase;
    z-index: 19;
  `;
  const ProfileDesg = styled.h4`
    font-size: 0.6em;
    font-family: "Montserrat";
    color: rgb(255, 255, 255);
    line-height: 3;
    text-align: center;
    z-index: 22;
    text-transform: uppercase;
  `;
  const SocialLinks = styled.div`
    padding: 30px 20px;
    display: flex;
    justify-content: space-around;
  `;

  const SocialName = styled.span`
    font-size: 0.7em;
    color: rgb(255, 255, 255);
    font-weight: bold;
    line-height: 2.333;
    text-align: left;
    padding-left: 20px;
  `;
  const Anchor = styled.a``;
  const Title = styled.h2`
    font-size: 1.18em;
    font-family: "Montserrat";
    color: rgb(1, 1, 1);
    font-weight: bold;
    line-height: 2.7;
    text-align: left;
    text-transform: uppercase;
  `;
  const InnerContainer = styled.div`
    margin-left: auto;
    margin-right: auto;
    padding: 40px 100px;
  `;
  const Divider = styled.div`
    width: 100%;
    background-color: rgb(54, 54, 54);
    height: 2px;
    margin: 50px 0;
  `;
  const TitleE = styled.h4`
    font-size: 0.85em;
    font-weight: 500;
    text-transform: uppercase;
    color: #1a1818;
  `;
  const About = styled.h5`
    font-size: 0.72em;
    color: #464749;
  `;
  const Description = styled.p`
    font-size: 0.72em;
    color: #6d6f72;
  `;
  const Education = styled.div`
    position: relative;

    :before {
      content: "";
      position: absolute;
      height: 8px;
      width: 8px;
      background-color: rgb(54, 54, 54);
      top: -88%;
      left: 30%;
      border-radius: 50%;
    }
  `;
  const DetailBox = styled.div`
    margin: 40px 0;
    position: relative;
    :before {
      content: "";
      height: 8px;
      width: 8px;
      position: absolute;
      border-radius: 50%;
      background-color: rgb(54, 54, 54);
      top: 5px;
      left: -35px;
    }
  `;
  const VerticalBox = styled.div`
    border-left: 1px solid rgb(54, 54, 54);
    padding-left: 30px;
    margin-top: 50px;
    h2 {
      position: relative;
      line-height: 1;
      :before {
        content: "";
        height: 15px;
        width: 15px;
        position: absolute;
        border-radius: 50%;
        top: 0px;
        left: -38px;
        background-color: white;
        border: 1px solid rgb(54, 54, 54);
      }
    }
  `;
  const Interest = styled.div`
    margin-top: 50px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  `;
  const InterestBox = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    h4 {
      color: #939598;
    }
  `;
  return (
    <Container>
      <MainSec>
        <ProfileName>ANA JONES</ProfileName>
        <ProfileDesg>Photographer</ProfileDesg>
        <SocialLinks>
          <Anchor>
            <img src={images.fb} alt="" />
            <SocialName>/facebook</SocialName>
          </Anchor>

          <Anchor>
            <img src={images.ln} alt="" />
            <SocialName>/linkedin</SocialName>
          </Anchor>

          <Anchor>
            <img src={images.tw} alt="" />
            <SocialName>/twitter</SocialName>
          </Anchor>
        </SocialLinks>
        <InnerContainer>
          <Title>Education</Title>
          <Divider></Divider>
          <div className="my-row">
            <div className="col-4 p-0">
              <Education>
                <TitleE>Bachelor Degree</TitleE>
                <About>State College Aug 03 - May 06</About>
                <Description>Write about your work and degreehere.</Description>
              </Education>
            </div>
            <div className="col-4 p-0">
              <Education>
                <TitleE>Bachelor Degree</TitleE>
                <About>State College Aug 03 - May 06</About>
                <Description>Write about your work and degreehere.</Description>
              </Education>
            </div>
            <div className="col-4 p-0">
              <Education>
                <TitleE>Bachelor Degree</TitleE>
                <About>State College Aug 03 - May 06</About>
                <Description>Write about your work and degreehere.</Description>
              </Education>
            </div>
          </div>

          <div className="my-row">
            <div className="col-6">
              <VerticalBox>
                <Title>Experience</Title>
                <DetailBox>
                  <TitleE>Senior photographer</TitleE>
                  <About>Company Name | May 2 - July 30</About>
                  <Description>
                    Write about your work and degreehere.
                  </Description>
                </DetailBox>
                <DetailBox>
                  <TitleE>FRELANCE PHOTOGRAPHY</TitleE>
                  <About>Company Name | May 2 - July 30</About>
                  <Description>
                    Write about your work and degreehere.
                  </Description>
                </DetailBox>
                <DetailBox>
                  <TitleE>Senior photographer</TitleE>
                  <About>Company Name | May 2 - July 30</About>
                  <Description>
                    Write about your work and degreehere.
                  </Description>
                </DetailBox>
              </VerticalBox>
            </div>
            <div className="col-6">
              <VerticalBox>
                <Title>Skills</Title>
                <DetailBox>
                  <TitleE>Communication</TitleE>
                  <ProgressBar
                    completed={90}
                    bgColor="rgb(54, 54, 54)"
                    height="5px"
                    isLabelVisible={false}
                    baseBgColor="#EBF0F1"
                  />
                </DetailBox>
                <DetailBox>
                  <TitleE>CREATIVITY</TitleE>
                  <ProgressBar
                    completed={90}
                    bgColor="rgb(54, 54, 54)"
                    height="5px"
                    isLabelVisible={false}
                    baseBgColor="#EBF0F1"
                  />
                </DetailBox>
                <DetailBox>
                  <TitleE>ORGANIZATION</TitleE>
                  <ProgressBar
                    completed={90}
                    bgColor="rgb(54, 54, 54)"
                    height="5px"
                    isLabelVisible={false}
                    baseBgColor="#EBF0F1"
                  />
                </DetailBox>
                <DetailBox>
                  <TitleE>TEAMWORK</TitleE>
                  <ProgressBar
                    completed={90}
                    bgColor="rgb(54, 54, 54)"
                    height="5px"
                    isLabelVisible={false}
                    baseBgColor="#EBF0F1"
                  />
                </DetailBox>
                <DetailBox>
                  <TitleE>DESIGN THINKING</TitleE>
                  <ProgressBar
                    completed={90}
                    bgColor="rgb(54, 54, 54)"
                    height="5px"
                    isLabelVisible={false}
                    baseBgColor="#EBF0F1"
                  />
                </DetailBox>
              </VerticalBox>
            </div>
            <div className="col-12">
              <Title>Interests</Title>
              <Interest>
                <InterestBox>
                  <img src={images.photography} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
                <InterestBox>
                  <img src={images.travel} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
                <InterestBox>
                  <img src={images.reading} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
                <InterestBox>
                  <img src={images.movies} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
                <InterestBox>
                  <img src={images.cup} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
                <InterestBox>
                  <img src={images.paint} alt="" />
                  <TitleE>Photography</TitleE>
                </InterestBox>
              </Interest>
            </div>
          </div>
        </InnerContainer>
      </MainSec>
    </Container>
  );
};
