import bg from "./bg.png";
import fb from "./fb.png";
import ln from "./ln.png";
import tw from "./tw.png";
import cup from "./cup.png";
import movies from "./movies.png";
import paint from "./paint.png";
import photography from "./photography.png";
import reading from "./reading.png";
import travel from "./travel.png";

export default {
  bg,
  fb,
  ln,
  tw,
  cup,
  movies,
  paint,
  photography,
  reading,
  travel,
};
