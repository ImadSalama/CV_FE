import React from "react";
import styled from "styled-components";
import images from "./assets";
import { CircularProgressbar } from 'react-circular-progressbar';
import {Line} from 'react-chartjs-2';
import 'react-circular-progressbar/dist/styles.css';


export default () => {
    const Container = styled.div`
      margin-left: auto;
      margin-right: auto;
      background-color : #FFE0E9;
      padding : 40px;
    `;
    const MainBox = styled.div`
        background-color : #FCFCFC;
        padding : 40px 60px;
    `;
    const ProfileDetail = styled.div`
        display : flex;
        justify-content : space-between ; 
        margin-bottom : 50px;
  `;
  const ProfileName = styled.h1`
    font-size : 36px;
    font-weight: 500 ;
    color : #522E38;
    text-transform : uppercase;
  `;
  const ProfileDesg = styled.h3`
  font-size: 18px;
  color: #FF9EBB;
  border-bottom: 1px solid #602437;
  text-transform: uppercase;
  width: 44%;
  padding-bottom: 8px;
        
  `;
  const WhiteBox = styled.div`
    position : relative ;
    padding : 40px 15px 20px;
    background : white;
    box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    -webkit-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    -moz-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    border-radius : 20px;
    margin : 20px 0;
  `;
const state = {
    labels: ['Job Title', 'Job Title' , 'Job Title', 'Job Title'],
    datasets: [
      {
        label: '',
        fill: false,
        lineTension: 0.5,
        backgroundColor: 'white',
        borderColor: '#FF9EBB34',
        borderWidth: 5,
        data: [64, 70, 71, 80]
      }
    ]
  }

const Footer = styled.div`
        background-color : #F0F3F9;
        padding: 50px 0;

        p{
            color : #1E1950;
            text-align : center;
        }
`;
const SocialFooter = styled.div`
        display : flex;
        justify-content : center ;
      
    `;
    const Heading = styled.h3`
    font-size :18px;
    font-weight : 500;
    color : #1E1950;
    position : relative;

`;
const ProfileDetails = styled.div``;

const Title = styled.h4`
   font-size : 12px;
    font-weight : 600;
    color : #522E3840 ;
    text-align: center;
    padding-top: 10px;
`;
const Description = styled.p`
    font-size : 18px;
    color :#522E3840;


`;
const ContentDetail = styled.p`
    font-size : 10px;
    color : #FF9EBB;
    margin : 0;
    padding-left : 10px;
    margin: 7px 0;
`;

const TitleName = styled.h5`
    font-size : 12px;
    font-weight : 600;
    color : white ;
    background-color :  #522E38;
    border-top-left-radius : 20px;
    padding : 10px 30px ;
    position : absolute ;
    top : 0;
    left : 0;
`;
const BorderBox = styled.div`
    border-top-left-radius : 20px;
    background-color :#8A2846;
    display: flex;
    align-items: center;
    margin-bottom: 10px;
`;
const Number = styled.h4`
    font-size : 28px;
    font-weight: normal;
    color :  white;
    padding-left: 5px;
`;
const Name = styled.h6`
    font-size: 12px;
    font-weight: normal;
    color :  white;
    padding-left: 25px ;


`;
const Leasure = styled.div`
    background-color: white;
    box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    -webkit-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    -moz-box-shadow: 0px 2px 20px 0px rgba(74,85,137,0.08);
    border-radius : 20px;
    position : relative;
    margin-top : 20px;
    padding-top: 50px;
    display: flex;
    justify-content: center;

    ::before{
        content : "Leasure";
        position: absolute;
        background-color: #522E38;
        height : 29px;
        width: 100%;
        top : 0;
        color: white;
        text-align: center;
        border-top-left-radius : 20px;
        border-top-right-radius : 20px;
        
    }
`;
const Label = styled.h4`
    font-size : 12px;
    font-weight : 500;
    color : #5B3F67;
 `;
const DetailBox = styled.div`
display : flex; 
flex-wrap: wrap ;

`;
const ContentMain = styled.div`
    margin-left : 40px;

    p{
        text-align : left;
    }

    h4{
        text-align : left ;
        position:relative ; 
        :before{
            content : "";
            position: absolute;
            height : 10px;
            width : 10px ;
            border-radius : 50%;
            background-color : white;
            border : 1px solid black;
            left : -20px;
            top : 4px ;

        }
    }
    
 `;
 const ContentDetails = styled.p`
 font-size : 10px;
 font-weight : 500;
 text-align : center ;
 color: #522E3840;
 line-height : 20px;
 margin : 0;
 padding-bottom : 10px;

`;
  const TitleSpan = styled.span`
  font-size : 11px;
  font-weight : 600 ;
  padding : 5px 10px;
  border-radius : 5px ;
  margin-left : auto;


`;
const LeasureBox = styled.div`
    img{
        margin-top: 20px;
      
    }
    
    
`;
const PersonalBox = styled.div`
    background-color: white;
    box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    -webkit-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    -moz-box-shadow: 0px 0px 5px -7px rgba(163,171,180,0.21);
    border-radius: 10px;
    padding : 25px 10px;

`;
const TitleDark = styled.h4`
    font-size: 10px;
    color : #522E38;
    display : flex;

`;
const Skills = styled.div`
    display: flex;
    flex-wrap : wrap;
    justify-content: space-between;
`;
const SkillsCircle = styled.div`
    height: 133px;
    width: 133px;
    border-radius: 50%;
    border: 8px solid #FF7AA2;
    display: flex;
    justify-content: center;
    align-items: center;
`;
 const SkillsContent = styled.p`
    font-size : 9px;
    font-weight: 600;
    color: #522E38;
    margin : 0;
 `;

    return (
      <Container>
     <MainBox>
        <ProfileDetail>
            <ProfileDetails>
            <ProfileName>
                Ana Jones
            </ProfileName>
            <ProfileDesg>
                Designer
            </ProfileDesg>

            </ProfileDetails>
            <ProfileDetails>
            <div className="d-flex align-items-center">
        <img src={images.email} alt="" />
        <ContentDetail>
          
            Email Address
        </ContentDetail>
        </div>
        <div className="d-flex align-items-center">
        <img src={images.phone} alt="" />
        <ContentDetail>
          
            Phone Number
        </ContentDetail>
        </div>
        <div className="d-flex align-items-center">
        <img src={images.location} alt="" />
        <ContentDetail>
          
            Home Address
        </ContentDetail>
        </div>
        </ProfileDetails>
        </ProfileDetail>
        <WhiteBox>
            <TitleName>
           Brief Summary
            </TitleName>
            <Description>
            Ana is a graphic designer who works in a web designing company. They often ask for quick designs and she would like to have the help of ready-made graphics, which you can later modify  to fit your needs. She likes her job a lot but what her passion is traveling and meeting people. Whenever she can, she hangs out with her friends and always says love to travel.
            </Description>
         </WhiteBox>
         <div className="my-row">
            <div className="col-2">
                <BorderBox>
                    <Number>+20</Number>
                    <Name>
                        Projects
                    </Name>
                </BorderBox>
                <BorderBox style={{backgroundColor : "#B9375E"}}>
                    <Number>+30</Number>
                    <Name>
                        Customers
                    </Name>
                </BorderBox>
                <BorderBox style={{backgroundColor : "#E05780"}}>
                    <Number>+3</Number>
                    <Name>
                        Years Experience
                    </Name>
                </BorderBox>
                <Leasure>
                  <LeasureBox>
                    <img src={images.travel} alt="" />
                    <Title>
                        Travel
                    </Title>
                    <img src={images.sports} alt="" />
                    <Title>
                        Sports
                    </Title>
                    <img src={images.videogames} alt="" />
                    <Title>
                         Video Games
                    </Title>
                    <img src={images.reading} alt="" />
                    <Title className="mb-5">
                        Reading
                    </Title>
                    </LeasureBox>
                </Leasure>
            </div>
            <div className="col-10">
                <div className="my-row">
                    <div className="col-6">
                    <WhiteBox className="m-0">
            <TitleName>
          Experience
            </TitleName>
           
              <PersonalBox>
                  <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Job title - company name
                <TitleSpan className="pink-span">
                    Current Job
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Job title - company name
                <TitleSpan className="light-pink">
                    9 Months
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
                                <DetailBox>
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Job title - company name
                <TitleSpan className="light-pink">
                   1 Year
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
                Write Your Text Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                <ContentDetails>
                Write about your designation and experience about work Here
                </ContentDetails>
                </ContentMain>
                                </DetailBox>
              </PersonalBox>
           
         </WhiteBox>
                    </div>
                    <div className="col-6">
                    <WhiteBox className="m-0">
            <TitleName>
          Education
            </TitleName>
           
              <PersonalBox>
                  <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Title  of Formation - School name
                <TitleSpan className="pink-span">
                    Current
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
              Formation Degree
                </ContentDetails>
               
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Title  of Formation - School name
                <TitleSpan className="light-pink">
                    1 Year
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
               Formation Degree
                </ContentDetails>
               
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Title  of Formation - School name
                <TitleSpan className="light-pink">
                    1 Year
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
               Formation Degree
                </ContentDetails>
               
                </ContentMain>
                                </DetailBox>
                                <DetailBox className="mb-1">
                <Label>
                    Month/Year
                </Label>
                <ContentMain>
                <TitleDark>
                Title  of Formation - School name
                <TitleSpan className="light-pink">
                    1 Year
                </TitleSpan>
                </TitleDark>
               
                <ContentDetails>
               Formation Degree
                </ContentDetails>
               
                </ContentMain>
                                </DetailBox>
              </PersonalBox>
           
         </WhiteBox>
                    </div>
                    <div className="col-12">
                    <WhiteBox>
                        <TitleName>
                            Software Skills
                        </TitleName>
                        <Skills>
                        <CircularProgressbar styles={{root:{
                            height: 133,
                            width: 133,
                        },
                        path:{
                            stroke: "#FF7AA2",
                        },  
                        text:{
                            fontSize: 10
                        }
                        }} value={50} text="Adobe XD" />

<CircularProgressbar styles={{root:{
                            height: 133,
                            width: 133,
                        },
                        path:{
                            stroke: "#FF7AA2",
                        }
                        ,text:{
                            fontSize: 10
                        }
                        }} value={50} text="Adobe XD" /> 
                        <CircularProgressbar styles={{root:{
                            height: 133,
                            width: 133,
                        },
                        path:{
                            stroke: "#FF7AA2",
                        }
                        ,text:{
                            fontSize: 10
                        }
                        }} value={50} text="Adobe XD" />
                         <CircularProgressbar styles={{root:{
                            height: 133,
                            width: 133,
                        },
                        path:{
                            stroke: "#FF7AA2",
                        }
                        ,text:{
                            fontSize: 10
                        }
                        }} value={50} text="Adobe XD" /> 
                        <CircularProgressbar styles={{root:{
                            height: 133,
                            width: 133,
                        },
                        path:{
                            stroke: "#FF7AA2",
                        }
                        ,text:{
                            fontSize: 10
                        }
                        }} value={50} text="Adobe XD" />
                        </Skills>
                    </WhiteBox>
                    </div>
                </div>
            </div>
        </div>
       <WhiteBox>
           <TitleName>
               Professional Goals
           </TitleName>
           <Line
          data={state}
          options={{
           
            legend:{
              display:false,
              position:'right'
            }
          }}
        />
       </WhiteBox>
         </MainBox>
      
         <Footer>
             <div className="my-row">
                 <div className="col-4">
                     <SocialFooter>
                    <img src={images.behance} alt="" />
                    </SocialFooter>
                    <ContentDetail>www.behance.net/aliraza37</ContentDetail>

                   
                 </div>
                 <div className="col-4">
                 <SocialFooter>
                    <img src={images.ln} alt="" />

                    </SocialFooter>
                    <ContentDetail>www.linkedin.com/aliraza</ContentDetail>

                 </div>
                 <div className="col-4">
                 <SocialFooter>
                    <img src={images.twitter} alt="" />

                    </SocialFooter>
                    <ContentDetail>www.linkedin.com/aliraza</ContentDetail>

                 </div>
             </div>
         </Footer>
      </Container>
    );
  };
  