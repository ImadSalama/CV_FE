import behance from "./behance.png";
import ln from "./ln.png";
import twitter from "./twitter.png";
import email from "./email.png";
import phone from "./phone.png";
import location from "./location.png";
import travel from "./travel.png";
import sports from "./sports.png";
import videogames from "./videogames.png";
import reading from "./reading.png";

export default {
    behance,
    ln,
    twitter,
    email,
    phone,
    location,
    travel,
    sports,
    videogames,
    reading,



    

};