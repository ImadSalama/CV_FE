import React from "react";
import styled from "styled-components";
import images from "./assets";
import 'react-circular-progressbar/dist/styles.css';
import ProgressBar from "@ramonak/react-progress-bar";


export default () => {
    const Container = styled.div`
      margin-left: auto;
      margin-right: auto;
      background-color : white;
      padding : 40px;
    `;
   const MainBox = styled.div`
    border-bottom : 31px solid #253237;
   `;
   const HeaderBox = styled.div`
        background-color: #FFEEDD;
        padding: 60px;
   `;
   const ProfileName = styled.h3`
        font-size: 2.25em;
        color: #9381FF;
        text-transform: uppercase;
        letter-spacing: 6px;

   `;
   const ProfileDesg = styled.h5`
        font-size: 1.1em;
        color: #253237;
        position: relative;
        text-transform: uppercase;
        ::after{
            content: "";
            position: absolute;
            height: 1px;
            width: 10%;
            background-color: #B8B8FF;
            left : 20%;
            top: 12px;
        }
   `;
const BodyBox = styled.div`
    background-color: #FFF9F3;
    padding: 50px;
    span{
        font-size: .6em;
        color: #253237;
        font-weight : 300;
        padding-left: 10px;
    }
`;
const TitleHeading = styled.h5`
    font-size: .8em;
    font-weight: 600;
    color: #253237;
    text-transform: uppercase;
    margin-bottom: 20px ;
`;
const SocialDetail = styled.div`

`;
const ContentDetail = styled.p`
    font-size: 1em;
    font-weight: normal;
    color: #25323751;
`;

const FullDivider = styled.div`
    height: 1px;
    width: 98%;
    margin: 30px auto;
    background-color: #B8B8FF;
`;
const FlexBox = styled.div`
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    margin-top : 20px;
`;
const Year = styled.h5`
    font-size: 1.1em;
    color: #253237;

`;
const ExperienceDetail = styled.div`
position: relative;
margin-left: 100px;
    :before{
        content: "";
        position: absolute;
        height: 10px;
        width: 10px;
        border-radius: 50%;
        background-color: white;
        left: -30px;
        border : 1px solid black;
        top: 6px;
    }
`;
const ContentHeading = styled.h4`
    font-size: 1.1em;
    color: #9381FF;
    font-weight: 600;
    text-transform: uppercase;
`;
const CompanyName = styled.h6`
    font-size: .75em;
    color: #253237;
    font-weight: 600;

`;
const SkillCircle = styled.div`
    height: 60px;
    width: 60px;
    border-radius: 50%;
    background-color: #253237;
    display: flex;
    justify-content: center;
    align-items: center;
    color:white;
    font-size: .5em;
    margin: 10px 5px 0 0 ;
`;
const SkillsFlex = styled.div`
    display: flex;
    flex-wrap: wrap;

    img{
        margin: 10px 30px 0 0 ;
    }
`;
const SkillsName = styled.p`
    font-size: .5em;
    color: #25323751;
    font-weight: normal;
`;
const ProjectsFlex = styled.div`
    display:flex;
    flex-wrap: wrap;
    margin: 15px 0;

    p{
        margin-left: 40px;
    }
`;
const Number = styled.h5`
    font-size: 1.37em;
    color:  #253237;
    font-weight: 600;
    position: relative;

    span{
        font-size: 1.37em;
        color:#9381FF;
        font-weight: 500;
        padding : 0;
        position: absolute;
        top: -20px;
        left:20px;
    }
`;

const SocialLinks = styled.div`
margin-left: 20px;

h5{
    color: #909393;
}
`;
    return (
      <Container>
          <MainBox>
              <HeaderBox>
                  <ProfileName>Melissa Cambage</ProfileName>
                  <ProfileDesg>Creative Director</ProfileDesg>
              </HeaderBox>
              <BodyBox>
                  <div className="my-row">
                      <div className="col-2" style={{borderRight: "1px solid #B8B8FF"}}>
                  <TitleHeading>Contact</TitleHeading>
                  <SocialDetail>
                  <img src={images.email} alt="" />
                  <span>Email Address</span>
                  </SocialDetail>
                 <SocialDetail>
                 <img src={images.phone} alt="" />
                  <span>Phone Number</span>
                 </SocialDetail>
                 <SocialDetail>
                     <img src={images.location} alt="" />
                     <span>Home Address</span>
                 </SocialDetail>
                 <SocialDetail>
                     <img src={images.ln} alt="" />
                     <span>
                         Linkedin.aliraza
                     </span>
                 </SocialDetail>
                  </div>
                  <div className="col-8">
                      <TitleHeading>Introduction</TitleHeading>
                    <ContentDetail>
                    Hi! I’m Melissa Cambage.  I’m a Creative Director born in Belarus, country with the world’s largest
population of bison, and based in a sunny Costa del Sol (Spain). I got my MA degree in Design &
Communication at Barcelona School of Design and Engineering. 
                    </ContentDetail>
                  </div>
                  <FullDivider></FullDivider>
                  </div>
                  <div className="my-row">
                      <div className="col-8">
                          <TitleHeading>Work Experience</TitleHeading>
                          <FlexBox>
                            <Year>
                                2004 - 2016
                            </Year>
                            <ExperienceDetail>
                            <ContentHeading>
                            CHIEF PROJECT MANAGER
                            </ContentHeading>
                            <CompanyName>Company Name</CompanyName>
                            <ContentDetail>
                                Write abour Your experience
                            </ContentDetail>
                            </ExperienceDetail>
                          </FlexBox>
                          <FlexBox>
                            <Year>
                                2004 - 2016
                            </Year>
                            <ExperienceDetail>
                            <ContentHeading>
                            CHIEF PROJECT MANAGER
                            </ContentHeading>
                            <CompanyName>Company Name</CompanyName>
                            <ContentDetail>
                                Write abour Your experience
                            </ContentDetail>
                            </ExperienceDetail>
                          </FlexBox>
                          <FlexBox>
                            <Year>
                                2004 - 2016
                            </Year>
                            <ExperienceDetail>
                            <ContentHeading>
                            CHIEF PROJECT MANAGER
                            </ContentHeading>
                            <CompanyName>Company Name</CompanyName>
                            <ContentDetail>
                                Write abour Your experience
                            </ContentDetail>
                            </ExperienceDetail>
                          </FlexBox>
                      </div>
                      <div className="col-4">
                          <TitleHeading>Software Skills</TitleHeading>
                            <SkillsFlex>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                                <SkillCircle>
                                    Sketch App
                                </SkillCircle>
                              

                            </SkillsFlex>
                            <TitleHeading className="mt-4">Skills</TitleHeading>
                            <SkillsName>
                                Wordpress
                            </SkillsName>
                            <ProgressBar completed={80}
                             bgColor="#253237"
                             height= "3px"
                             isLabelVisible= {false}
                             

                             />
                              <SkillsName>
                                Wordpress
                            </SkillsName>
                            <ProgressBar completed={60}
                             bgColor="#253237"
                             height= "3px"
                             isLabelVisible= {false}
                             

                             />
                              <SkillsName>
                                Wordpress
                            </SkillsName>
                            <ProgressBar completed={40}
                             bgColor="#253237"
                             height= "3px"
                             isLabelVisible= {false}
                             

                             />
                              <SkillsName>
                                Wordpress
                            </SkillsName>
                            <ProgressBar completed={70}
                             bgColor="#253237"
                             height= "3px"
                             isLabelVisible= {false}
                             

                             />
                      </div>
                      <FullDivider></FullDivider>
                  </div>
                  <div className="my-row">
                      <div className="col-8">
                          <TitleHeading>Eduction Details</TitleHeading>
                          <FlexBox>
                            <Year>
                                2004 - 2016
                            </Year>
                            <ExperienceDetail>
                            <ContentHeading>
                            CHIEF PROJECT MANAGER
                            </ContentHeading>
                            <CompanyName>Company Name</CompanyName>
                            <ContentDetail>
                                Write abour Your experience
                            </ContentDetail>
                            </ExperienceDetail>
                          </FlexBox>
                          <FlexBox>
                            <Year>
                                2004 - 2016
                            </Year>
                            <ExperienceDetail>
                            <ContentHeading>
                            CHIEF PROJECT MANAGER
                            </ContentHeading>
                            <CompanyName>Company Name</CompanyName>
                            <ContentDetail>
                                Write abour Your experience
                            </ContentDetail>
                            </ExperienceDetail>
                          </FlexBox>
                      </div>
                      <div className="col-4">
                          <TitleHeading>
                              Interests
                          </TitleHeading>
                          <SkillsFlex>
                              <img src={images.plane} alt="" />
                              <img src={images.weight} alt="" />
                              <img src={images.video} alt="" />
                              <img src={images.skippingrope} alt="" />
                              <img src={images.bike} alt="" />
                              <img src={images.music} alt="" />
                              <img src={images.car} alt="" />
                              <img src={images.swimmer} alt="" />
                              <img src={images.football} alt="" />
                              <img src={images.football2} alt="" />
                              <img src={images.gamepad} alt="" />
                              <img src={images.running} alt="" />
                          </SkillsFlex>
                      </div>
                      <FullDivider></FullDivider>
                  </div>
                  <div className="my-row">
                    <div className="col-8">
                        <TitleHeading>Projects</TitleHeading>
                        <ProjectsFlex>
                        <Number>60 <span>+</span></Number>
                        <ContentDetail>Adapting and creating solutions for customer's needs</ContentDetail>
                        </ProjectsFlex>
                        <TitleHeading>Technical Solutions</TitleHeading>
                        <ProjectsFlex>
                        <Number>60 <span>%</span></Number>
                        <ContentDetail>Adapting and creating solutions for customer's needs</ContentDetail>
                        </ProjectsFlex>
                        <TitleHeading>Web</TitleHeading>
                        <ProjectsFlex>
                        <Number>60 <span>%</span></Number>
                        <ContentDetail>Adapting and creating solutions for customer's needs</ContentDetail>
                        </ProjectsFlex>
                        <TitleHeading>LEading</TitleHeading>
                        <ProjectsFlex>
                        <Number>60 <span>%</span></Number>
                        <ContentDetail>Adapting and creating solutions for customer's needs</ContentDetail>
                        </ProjectsFlex>
                    </div>
                    <div className="col-4">
                        <TitleHeading>
                            Social Links
                        </TitleHeading>
                        <FlexBox>
                            <img src={images.facebook} alt="" />
                            <SocialLinks>
                                <Year>Facebook</Year>
                                    <ContentDetail>facebook.com/username</ContentDetail>
                            </SocialLinks>
                        </FlexBox>
                        <FlexBox>
                            <img src={images.twitter} alt="" />
                            <SocialLinks>
                                <Year>Twitter</Year>
                                    <ContentDetail>facebook.com/username</ContentDetail>
                            </SocialLinks>
                        </FlexBox>
                        <FlexBox>
                            <img src={images.behance} alt="" />
                            <SocialLinks>
                                <Year>Behnace</Year>
                                    <ContentDetail>facebook.com/username</ContentDetail>
                            </SocialLinks>
                        </FlexBox>
                        <FlexBox>
                            <img src={images.linkedin} alt="" />
                            <SocialLinks>
                                <Year>LinkedIn</Year>
                                    <ContentDetail>facebook.com/username</ContentDetail>
                            </SocialLinks>
                        </FlexBox>

                    </div>
                  </div>
              </BodyBox>
          </MainBox>
      </Container>
    );
  };
  