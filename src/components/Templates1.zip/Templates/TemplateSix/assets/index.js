import email from "./email.svg";
import phone from "./phone.svg";
import location from "./location.svg";
import ln from "./ln.svg";
import car from "./car.svg";
import football from "./football.svg";
import football2 from "./football2.svg";
import gamepad from "./gamepad.svg";
import music from "./music.svg";
import plane from "./plane.svg";
import running from  "./running.svg";
import skippingrope from "./skipping-rope.svg";
import swimmer from "./swimmer.svg";
import video from "./video.svg";
import weight from "./weight.svg";
import bike from "./bike.svg";
import facebook from "./facebook.svg";
import twitter from "./twitter.svg";
import behance from "./behance.svg";
import linkedin from "./linkin.svg";


export default {
    email,
    phone,
    location,
    ln,
    car,
    football,
    football2,
    gamepad,
    music,
    plane,
    running,
    skippingrope,
    swimmer,
    video,
    weight,
    bike,
    facebook,
    linkedin,
    behance,
    twitter,



}