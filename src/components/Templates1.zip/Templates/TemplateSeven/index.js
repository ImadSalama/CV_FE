import React from "react";
import styled from "styled-components";
import images from "./assets";
import 'react-circular-progressbar/dist/styles.css';
import { CircularProgressbar } from 'react-circular-progressbar';
import ProgressBar from "@ramonak/react-progress-bar";

export default () => {
    const Container = styled.div`
      margin-left: auto;
      margin-right: auto;
      background-color : #F3F3F3;
      padding : 40px;
      position: relative;

      :before{
          content: "";
          position: absolute;
          background: url("${images.shape4}");
            height: 100%;
            width: 20%;
          background-size: cover;
          top: 0;
          left: -14%;
      }
      :after{
          content: "";
          position: absolute;
          background: url("${images.shape1}");
            height: 200px;
            width: 200px;
          background-size: cover;
          top: -70px;
          right: 0;
      }
    `;
    const LightTemplate = styled.div`
        color: #3B2828;
    `;
  const Profile = styled.div `
        background-color: #FFE32C;
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        min-height: 400px;
  `;
  const ProfileName = styled.h3`
  font-size: 2em;
  font-weight: bold;
  color: #3B2828;

  `;
  const ProfileDesg = styled.h4`
        font-size: 1.2em;
        color: #232323;


  `;
  const PersonalInfo = styled.div`
    background-color: white;
    padding : 40px 20px;
    position: relative;
    z-index: 55555;

    
  `;
  const InfoTitle = styled.h3`
    color: #3B2828;
    font-size: 1em;
    opacity: 54%;
    margin-top: 20px;
    
  `;
  const InfoDetail = styled.div`
        margin: 30px 0;
  `;
  const Title = styled.h4`
    color: #3B2828;
    font-size: .8em;
    font-weight: bold;
  `;
  const Description = styled.h6`
        color: #3B2828;
        font-size: .6em;
  `;
  const FullDivider = styled.div`
    height: 1px;
    width: 100%;
    background: #000000;
    opacity: 20%;
    margin: 10px 0;
  `;
  const DetailBox = styled.div`
    background: white;
    padding: 40px 20px;
    position: relative;
    z-index : 5555;

    h3{
        opacity: 1;
        margin-bottom: 20px;
    }

  `;
  const TitleRight = styled.h1`
        font-size: 2.2em;
        color: #FFE32C;
        font-weight: bold;
  `;
  const AboutMe = styled.p`
        font-size: 1em;
        color : #3B2828;

  `;
  const ProgressBarMain = styled.div`
      margin-right: 10px;
    h4{
        text-align: center;
    }
  `;
  const FlexBox = styled.div`
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        height: 70%;
  `;
  const SkillName = styled.h5`
  color: #3B2828;
  font-size: 1em;
  font-weight: bold;
  `;
const FlexBetween = styled.div`
    margin-top: 10px;
    display: flex;
    justify-content: space-between;
`;
const Badge = styled.div`
    background-color: #FFE32C;
    padding: 5px 0;
    color: #3B2828;
    text-align: center;
    border-top-right-radius: 20px;
    border-bottom-right-radius: 20px;
    width: 30%;
    font-size: .7em;
    position: relative;

    
`;
const BoxFlex = styled.div`
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;

`;
const Details = styled.div`
    margin-left: 20px;
    width: 58%;
    border-left: 1px solid #C1E3E7;
    padding-left: 20px;
    position: relative;

    :before{
        content: "";
        height : 4px;
        width: 4px;
        border-radius: 50%;
        background-color: black;
        position: absolute;
        top: 5px;
        left : -3px;
    }
`;
const DetailsHeading = styled.h2`
    font-size: 1.2em;
    color: #3B2828;
`;
const DetailsDesg = styled.h4`
    font-size: 1.1em;
    color: #3B2828;
    opacity: 54%;
`;
const DetailsContent = styled.p`
    font-size: .8em;
    color : #3B2828;


`;
const IntrestName = styled.span`
    font-size: 1em;
    color: #3B2828;
    padding-left: 20px;
`;
const Interest = styled.div`
    img{
        height: 20px;
        width: 40px;
        margin-bottom: 10px;
    }
`;
    return (
      <Container>
          <LightTemplate>
         <div className="my-row">
             <div className="col-4">
                <Profile>
                    <ProfileName>
                    Jon Snow
                    </ProfileName>
                    <ProfileDesg>
                    Graphic Designer
                    </ProfileDesg>
                </Profile>
                <PersonalInfo>
                    <InfoTitle>
                        Personal Information
                    </InfoTitle>
                    <InfoDetail>
                        <Title>Name</Title>
                        <Description>Jon Snow</Description>
                    </InfoDetail>
                    <InfoDetail>
                        <Title>D . O . B</Title>
                        <Description>04/11/1997</Description>
                    </InfoDetail>
                    <InfoDetail>
                        <Title>Address</Title>
                        <Description>123, Main Street, New York,USA 456123
</Description>
                    </InfoDetail>
                    <InfoDetail>
                        <Title>Email</Title>
                        <Description>Jonsnow@email.com</Description>
                    </InfoDetail>
                    <InfoDetail>
                        <Title>Phone</Title>
                        <Description>123456789</Description>
                    </InfoDetail>
                    <FullDivider>

                    </FullDivider>
                    <InfoTitle>
                        Languages
                    </InfoTitle>
                    <InfoDetail>
                        <Title>Name</Title>
                        <Description>Jon Snow</Description>
                    </InfoDetail>
                    <InfoDetail>
                        <Title>D . O . B</Title>
                        <Description>04/11/1997</Description>
                    </InfoDetail>
                  
                </PersonalInfo>
             </div>
             <div className="col-8">
                <DetailBox>
                    <TitleRight>
                    Hello, I’m  Jon Snow! 
                    </TitleRight>
                    <AboutMe>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </AboutMe>
                    <FullDivider></FullDivider>
                    <div className="my-row">
                        <div className="col-6">
                    <InfoTitle>
                        Personal Skills
                    </InfoTitle>
                    <FlexBox>
                    <ProgressBarMain>
                    <CircularProgressbar styles={{root:{
                            height: 70,
                            width: 70,
                        },
                        path:{
                            stroke: "#FFE32C",
                            strokeWidth: "5px",
                        },  
                        text:{
                            fontSize: 10
                        }
                        ,
                        trail:{
                            stroke: "white",
                        },
                        
                        }} counterClockwise={true} value={90} text="90%" />
                        <Title>
                            UX Design
                        </Title>
                    </ProgressBarMain>

                    
                    <ProgressBarMain>
                    <CircularProgressbar styles={{root:{
                            height: 70,
                            width: 70,
                        },
                        path:{
                            stroke: "#FFE32C",
                            strokeWidth: "5px",
                        },  
                        text:{
                            fontSize: 10
                        }
                        ,
                        trail:{
                            stroke: "white",
                        },
                        
                        }} counterClockwise={true} value={70} text="70%" />
                          <Title>
                            PHP MySql
                        </Title>
                    </ProgressBarMain>
                    <ProgressBarMain>
                    <CircularProgressbar styles={{root:{
                            height: 70,
                            width: 70,
                        },
                        path:{
                            stroke: "#FFE32C",
                            strokeWidth: "5px",
                        },  
                        text:{
                            fontSize: 10
                        }
                        ,
                        trail:{
                            stroke: "white",
                        },
                        
                        }} counterClockwise={true} value={66} text="66%" />
                          <Title>
                            UX Design
                        </Title>
                    </ProgressBarMain>
                    </FlexBox>
                    </div>
                    <div className="col-6">
                        <InfoTitle>
                            Professional Skills
                        </InfoTitle>
                        <FlexBetween>
                        <SkillName>
                            Php MySql
                       
                        </SkillName>
                        <SkillName>
                            90%
                        </SkillName>
                        </FlexBetween>
                     
                        <ProgressBar completed={90}
                             bgColor="#FFE32C"
                             height= "5px"
                             isLabelVisible= {false}
                             baseBgColor="#EBF0F1"
                             

                             />
                              <FlexBetween>
                        <SkillName>
                            Php MySql
                       
                        </SkillName>
                        <SkillName>
                            90%
                        </SkillName>
                        </FlexBetween>
                     
                        <ProgressBar completed={90}
                             bgColor="#FFE32C"
                             height= "5px"
                             isLabelVisible= {false}
                             baseBgColor="#EBF0F1"
                             

                             />
                              <FlexBetween>
                        <SkillName>
                            Php MySql
                       
                        </SkillName>
                        <SkillName>
                            90%
                        </SkillName>
                        </FlexBetween>
                     
                        <ProgressBar completed={90}
                             bgColor="#FFE32C"
                             height= "5px"
                             isLabelVisible= {false}
                             baseBgColor="#EBF0F1"
                             

                             />
                              <FlexBetween>
                        <SkillName>
                            Php MySql
                       
                        </SkillName>
                        <SkillName>
                            90%
                        </SkillName>
                        </FlexBetween>
                     
                        <ProgressBar completed={90}
                             bgColor="#FFE32C"
                             height= "5px"
                             isLabelVisible= {false}
                             baseBgColor="#EBF0F1"
                             

                             />
                    </div>
                    </div>
                    <FullDivider style={{margin:"30px 0"}}></FullDivider>
                    <div className="my-row">
                        <div className="col-6">
                            <InfoTitle>
                                Work Experience
                            </InfoTitle>
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                           
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            </BoxFlex> 
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            </BoxFlex> 
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            
                            </BoxFlex> 
                        </div>
                        <div className="col-6">
                            <InfoTitle>
                               Education
                            </InfoTitle>
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            </BoxFlex> 
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            </BoxFlex> 
                            <BoxFlex>
                            <Badge>
                                2014 - 2016
                            </Badge>
                            <Details>
                                <DetailsHeading>
                                    Team Leader
                                </DetailsHeading>
                                <DetailsDesg>
                                    Design Group
                                </DetailsDesg>
                                <DetailsContent>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
                                </DetailsContent>
                            </Details>
                            </BoxFlex> 
                        </div>
                    </div>
                    <FullDivider>

                    </FullDivider>
                    <InfoTitle>Interests</InfoTitle>
                    <Interest>
                    <div className="my-row">
                        <div className="col-4">
                            <img src={images.music} alt="" />
                            <IntrestName>Music</IntrestName>
                        </div>
                        <div className="col-4">
                            <img src={images.swimming} alt="" />
                            <IntrestName>Swimming</IntrestName>
                        </div>
                        <div className="col-4">
                            <img src={images.trekking} alt="" />
                            <IntrestName>Trekking</IntrestName>
                        </div>
                        <div className="col-4">
                            <img src={images.art} alt="" />
                            <IntrestName>Art</IntrestName>
                        </div>
                        <div className="col-4">
                            <img src={images.tennis} alt="" />
                            <IntrestName>Tennis</IntrestName>
                        </div>
                        <div className="col-4">
                            <img src={images.reading} alt="" />
                            <IntrestName>Reading</IntrestName>
                        </div>
                       
                    </div>
                    </Interest>
                </DetailBox>
             </div>
         </div>
         </LightTemplate>
      </Container>
    );
  };
  