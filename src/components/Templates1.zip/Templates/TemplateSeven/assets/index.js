import art from "./art.svg";
import music from "./music.svg";
import reading from "./reading.svg";
import swimming from "./swimming.svg";
import tennis from "./tennis.svg";
import trekking from "./trekking.svg";
import bg from "./bg.svg";
import shape1 from "./shape1.svg";
import shape2 from "./shape2.svg";
import shape3 from "./shape3.svg";
import shape4 from "./shape4.svg";
export default {
    art,
    music,
    reading,
    swimming,
    tennis,
    trekking,
    bg,
    shape1,
    shape2,
    shape3,
    shape4,


}