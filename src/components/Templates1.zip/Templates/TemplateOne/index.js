import React from "react";
import styled from "styled-components";
import icons from "./assets";

export default () => {
  const Container = styled.div`
    height: 2000px;
    /* width: 850px; */
    margin-left: auto;
    margin-right: auto;
  `;

  const BlockQuote = styled.blockquote`
    position: relative;
    text-align: center;
    padding: 1rem 1.2rem;
    color: #484748;
    margin: 1rem 0px 2rem;
    height: fit-content;
    background-color: rgba(237, 185, 15, 0.29);

    /* background: linear-gradient(to right, #039be5 4px, transparent 4px) 0 100%,
      linear-gradient(to left, #039be5 4px, transparent 4px) 100% 0,
      linear-gradient(to bottom, #039be5 4px, transparent 4px) 100% 0,
      linear-gradient(to top, #039be5 4px, transparent 4px) 0 100%;
    background-repeat: no-repeat;
    background-size: 20px 20px; */
    :before {
      font-family: FontAwesome;
      position: absolute;
      color: #edb910;
      font-size: 2.125em;
      content: "\f10d";
      top: -12px;
      margin-right: -20px;
      right: 100%;
    }
    :after {
      font-family: FontAwesome;
      position: absolute;
      color: #edb910;
      font-size: 2.125em;
      content: "\f10e";
      margin-left: -20px;
      left: 100%;
      top: auto;
      bottom: -20px;
    }
  `;

  const BiographyContainer = styled.div``;

  const BiographyTitle = styled.strong`
    font-size: 1.56em;
    color: #edb910;
  `;

  const Biography = styled.p`
    text-align: justify;
  `;

  const PersonalityContainer = styled.div``;

  const PersonalityTitle = styled.strong`
    font-size: 1.56em;
    color: #edb910;
  `;

  const Personality = styled.div`
    display: flex;
  `;

  const PersonalityDiv = styled.div`
    border: 1px solid #edb910;
    border-radius: 20px;
    padding: 5px;
    width: 25%;
    text-align: center;
    margin-right: 10px;
  `;

  const PersonalInfo = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #2d323a;
    padding: 20px 0px;
  `;

  const FullName = styled.strong`
    font-size: 2.31em;
    color: white;
  `;

  const Occupation = styled.strong`
    color: #edb910;
    font-size: 1.56em;
  `;

  const UserDetails = styled.div`
    color: white;
  `;

  const Detail = styled.div`
    width: 100%;
    font-size: 0.8em;
    margin: 5px 0px;
    display: flex;
  `;

  const DetailIcon = styled.img`
    width: 1.2rem;
    height: 1.2rem;
    color: white;
  `;

  const DetailText = styled.p`
    color: white;
    margin-bottom: 0px;
    display: inline;
  `;

  const NatureContianer = styled.div``;

  const MotivationsContainer = styled.div`
    display: flex;
  `;
  const GreenStraightLine = styled.div`
    border-left: 3px solid #d8ffc2;
  `;

  const RedStraightLine = styled.div`
    border-left: 3px solid #ffdcdc;
  `;

  const Motivations = styled.div``;

  const ScenerioContainer = styled.div`
    background-color: #f6f6f6;
    padding: 10px;
    border-radius: 5px;
    margin-top: 50px;
  `;

  const ScenerioTitle = styled.strong`
    font-size: 1.56em;
    color: #edb910;
  `;

  const Scenerio = styled.div`
    text-align: justify;
  `;

  const References = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    margin-top: 20%;
  `;

  const RefText = styled.strong`
    font-size: 1.56em;
    color: #edb910;
  `;

  const Influences = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  `;

  const ProfileImage = styled.div`
    overflow: hidden;
    display: flex;
    justify-content: center;
  `;

  const InfluenceIcon = styled.img`
    height: 1.5em;
    width: 1.5em;
  `;

  return (
    <Container>
      <div className="my-row">
        <div className="col-4">
          <ProfileImage>
            <img src={"https://picsum.photos/600"} height={600} />
          </ProfileImage>
          <PersonalInfo>
            <FullName>Bilal Ahmad</FullName>
            <Occupation>Software Engineer</Occupation>
            <UserDetails>
              <Detail>
                <div className="col-2 my-row justify-content-center">
                  <DetailIcon src={icons.cake} />
                </div>
                <div className="col-10">
                  <DetailText>28 year Old</DetailText>
                </div>
              </Detail>
              <Detail>
                <div className="col-2 my-row justify-content-center">
                  <DetailIcon src={icons.heart} />
                </div>
                <div className="col-10">
                  <DetailText>Single</DetailText>
                </div>
              </Detail>
              <Detail>
                <div className="col-2 my-row justify-content-center">
                  <DetailIcon src={icons.destination} />
                </div>
                <div className="col-10 ">
                  <DetailText>Pakistan</DetailText>
                </div>
              </Detail>
              <Detail>
                <div className="col-2 my-row justify-content-center">
                  <DetailIcon src={icons.bear} />
                </div>
                <div className="col-10">
                  <DetailText>No Kids</DetailText>
                </div>
              </Detail>
              <Detail>
                <div className="col-2 my-row justify-content-center">
                  <DetailIcon src={icons.graduation} />
                </div>
                <div className="col-10">
                  <DetailText>Multimedia Designer</DetailText>
                </div>
              </Detail>
            </UserDetails>
          </PersonalInfo>
          <References>
            <RefText> References and Influences</RefText>
            <div className="my-row pt-5">
              <Influences className="col-6">
                <InfluenceIcon src={icons.support} />
                <div>Friends</div>
              </Influences>
              <Influences className="col-6">
                <InfluenceIcon src={icons.book} />
                <div>Reading</div>
              </Influences>
            </div>

            <div className="my-row pt-5">
              <Influences className="col-6">
                <InfluenceIcon src={icons.music} />
                <div>Music</div>
              </Influences>
              <Influences className="col-6">
                <InfluenceIcon src={icons.travelling} />
                <div>Travelling</div>
              </Influences>
            </div>
          </References>
        </div>
        <div className="col-8">
          <BlockQuote>
            It’s good to meet you, Dr. Banner. Your work on anti-electron
            collisions is unparalleled. And I’m a huge fan of the way you lose
            control and turn into an enormous green rage monster.
            <cite> - Tony Stark</cite>
          </BlockQuote>
          <BiographyContainer>
            <BiographyTitle>Biography</BiographyTitle>
            <Biography>
              Tina is a graphic designer who works in a web designing company.
              They often ask for quick designs and she would like to have the
              help of ready-made graphics, which you can later modify to fit
              your needs.
              <br />
              She likes her job a lot but what her passion is traveling and
              meeting people. Whenever she can, she hangs out with her friends
              and always says love to travel. She loves music and plays guitar.
              <br />
              She likes her job a lot but what her passion is traveling and
              meeting people. Whenever she can, she hangs out with her friends
              and always says love to travel. She loves music and plays guitar.
              <br />
              She likes her job a lot but what her passion is traveling and
              meeting people. Whenever she can, she hangs out with her friends
              and always says love to travel. She loves music and plays guitar.
            </Biography>
          </BiographyContainer>
          <PersonalityContainer>
            <PersonalityTitle>Personality</PersonalityTitle>
            <Personality>
              <PersonalityDiv> Organised </PersonalityDiv>
              <PersonalityDiv> Organised </PersonalityDiv>
              <PersonalityDiv> Organised </PersonalityDiv>
              <PersonalityDiv> Organised </PersonalityDiv>
            </Personality>
            <div className="row mt-4">
              <NatureContianer className="col-6">
                <MotivationsContainer>
                  <GreenStraightLine></GreenStraightLine>
                  <Motivations className="ml-4">
                    <div>
                      <i className="fa fa-thumbs-up"></i>
                      <strong className="ml-2">Motivations</strong>
                    </div>
                    <div>
                      <div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                      </div>
                    </div>
                  </Motivations>
                </MotivationsContainer>
              </NatureContianer>
              <NatureContianer className="col-6">
                <MotivationsContainer>
                  <RedStraightLine></RedStraightLine>
                  <Motivations className="ml-4">
                    <div>
                      <i className="fa fa-thumbs-down"></i>
                      <strong className="ml-2">Frustration</strong>
                    </div>
                    <div>
                      <div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                        <div>- Finish work quickly to have free time.</div>
                      </div>
                    </div>
                  </Motivations>
                </MotivationsContainer>
              </NatureContianer>
            </div>
          </PersonalityContainer>
          <ScenerioContainer>
            <ScenerioTitle>Scenerio</ScenerioTitle>
            <Scenerio>
              Marta just arrived at the office and they ask her to make a banner
              to offer Valentine's offers from a web page.
            </Scenerio>
            <Scenerio>
              She has ideas but decides to search the Freepik for the latest
              Valentine designs to see current trends.
            </Scenerio>
            <Scenerio>
              There are many quality designs that Marta likes and she decides to
              download some to make her own design.
            </Scenerio>
            <Scenerio>
              Once finished, she shows it to the boss. He and the client like
              it. Perfect, you can now continue with other tasks.
            </Scenerio>
          </ScenerioContainer>
        </div>
      </div>
    </Container>
  );
};
