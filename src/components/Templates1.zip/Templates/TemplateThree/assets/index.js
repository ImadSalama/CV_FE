import profileimg from './profile.png';
import email from './email.svg';
import phone from "./phone.svg";
import location from "./location.svg";
import ln from "./ln.svg";
import drible from "./drible.svg";
import behance from "./behance.svg";
import travel from "./travel.svg";
import reading from "./reading.svg";
import videogames from "./videogames.svg";
import sports from "./sports.svg";

export default {
    profileimg,
    email,
    phone,
    location,
    ln,
    drible,
    behance,
    travel,
    reading,
    videogames,
    sports,



};
