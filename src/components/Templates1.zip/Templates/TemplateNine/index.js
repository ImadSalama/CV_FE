import React from "react";
import styled from "styled-components";
import "react-circular-progressbar/dist/styles.css";
import ProgressBar from "@ramonak/react-progress-bar";
import images from "./assets";

export default () => {
  const Container = styled.div`
    margin-left: auto;
    margin-right: auto;
    background-color: #d5d8eb;
    padding: 50px;
    position: relative;
  `;
  const ProfileName = styled.h1`
    font-size: 2em;
    font-family: "Montserrat";
    color: #626db7;
    text-transform: uppercase;
    line-height: 0.938;
    text-align: center;
  `;
  const ProfileDesg = styled.h3`
    font-size: 1em;
    font-family: "Montserrat";
    color: #626db7;
    text-transform: uppercase;
    line-height: 1;
    text-align: center;
  `;
  const Divider = styled.div`
    height: 5px;
    width: 100%;
    background-color: #626db7;
    margin: 30px 0;
  `;
  const Box = styled.div`
    border-radius: 19px;
    background-color: #d5d8eb;
    box-shadow: 0px 0px 28.13px 0.87px #626db7;
    padding: 25px;
    margin: 25px 0;
  `;
  const Title = styled.h3`
    font-size: 1.5em;
    font-family: "Montserrat";
    color: #626db7;
    text-transform: uppercase;
    line-height: 0.938;
    text-align: left;
    font-weight: bold;
  `;
  const Content = styled.p`
    font-size: 0.8em;
    font-family: "Roboto";
    color: #626db7;
    line-height: 1.556;
  `;
  const Summary = styled.div`
    border-right: 1px solid #626db7;
    p {
      width: 75%;
    }
  `;
  const Profile = styled.div`
    margin-left: auto;
    width: 75%;
  `;
  const ProfileContent = styled.div`
    display: flex;
    flex-wrap: wrap;
    margin-top: 20px;
  `;
  const ProfileDetail = styled.div`
    font-size: 0.8em;
    font-family: "Roboto";
    color: #626db7;
    border-left: 1px solid #626db7;
    padding-left: 20px;
    margin-left: 10px;
  `;
  const Experience = styled.div`
    margin-top: 20px;
    .my-row .col-4 {
      border-right: 1px solid #626db7;
      padding-left: 80px !important;
    }
    .my-row .col-4:last-child {
      border: 0;
    }
    .my-row .col-4:first-child {
      padding-left: 0px !important;
    }
  `;
  const TitleSmall = styled.h4`
    font-size: 1em;
    font-weight: bold;
    color: #626db7;
  `;
  const NumberBullet = styled.li`
    margin-left: 15px;
    list-style: decimal;
    color: #626db7;
    font-size: 0.8em;
  `;
  const SkillsBox = styled.div`
    display: flex;
    align-items: center;
    span {
      padding: 0px 20px 0 0;
    }
    span:last-child {
      padding: 0 20px;
    }
  `;
  const Span = styled.span`
    font-size: 0.8em;
    color: #626db7;
    font-weight: bold;
    width: 50%;
  `;
  const Hobbies = styled.div`
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 20px;
  `;
  const HobbiesBox = styled.div`
    max-width: 30%;
    width: 30%;
    margin-right: 2%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  `;
  return (
    <Container>
      <ProfileName>ANA JONES</ProfileName>
      <ProfileDesg>Web Designer</ProfileDesg>
      <Divider></Divider>
      <Box>
        <div className="my-row">
          <div className="col-6">
            <Summary>
              <Title>Summary</Title>
              <Content>
                Hi! I’m Ana. I’m a graphic designer born in Belarus, country
                with the world’s largest population of bison, and based in a
                sunny Costa del Sol (Spain). I got my MA degree in Design &
                Communication at Barcelona School of Design and Engineering. b
                orum. Sed ut perspiciatis unde omnis iste natus error sit
                voluptatem accusantiumdol oremque laudantium, totam rem aperiam,
                eaque ipsa quae ab illo inventore veritatis et quasi architecto
                beatae vitae dicta sunt explicabo.
              </Content>
            </Summary>
          </div>
          <div className="col-6">
            <Profile>
              <Title>Profile</Title>
              <ProfileContent>
                <img src={images.name} alt="" />
                <ProfileDetail>Ana Jones</ProfileDetail>
              </ProfileContent>
              <ProfileContent>
                <img src={images.dob} alt="" />
                <ProfileDetail>June 1, 1997</ProfileDetail>
              </ProfileContent>
              <ProfileContent>
                <img src={images.address} alt="" />
                <ProfileDetail>108 W Skillet Ave, Dayton, 50530</ProfileDetail>
              </ProfileContent>
              <ProfileContent>
                <img src={images.phone} alt="" />
                <ProfileDetail>(603) 123 456 789</ProfileDetail>
              </ProfileContent>
              <ProfileContent>
                <img src={images.mail} alt="" />
                <ProfileDetail>youremailid@gmail.com</ProfileDetail>
              </ProfileContent>
              <ProfileContent>
                <img src={images.website} alt="" />
                <ProfileDetail>www.yourwebsite.com</ProfileDetail>
              </ProfileContent>
            </Profile>
          </div>
        </div>
      </Box>
      <Box>
        <Title>Experience</Title>
        <Experience>
          <div className="my-row">
            <div className="col-4 p-0">
              <TitleSmall>Company Name</TitleSmall>
              <Content>Graphic Designer | 2014 - Present</Content>
              <TitleSmall>Major Job Responsibilities:</TitleSmall>
              <ul>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
              </ul>
            </div>
            <div className="col-4 p-0">
              <TitleSmall>Company Name</TitleSmall>
              <Content>Graphic Designer | 2014 - Present</Content>
              <TitleSmall>Major Job Responsibilities:</TitleSmall>
              <ul>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
              </ul>
            </div>
            <div className="col-4 p-0">
              <TitleSmall>Company Name</TitleSmall>
              <Content>Graphic Designer | 2014 - Present</Content>
              <TitleSmall>Major Job Responsibilities:</TitleSmall>
              <ul>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
                <NumberBullet>Your Main Work</NumberBullet>
              </ul>
            </div>
          </div>
        </Experience>
      </Box>
      <Box>
        <Title>Education</Title>
        <Experience>
          <div className="my-row">
            <div className="col-4 p-0">
              <TitleSmall>Post Graduate in Graphic Design</TitleSmall>
              <Content className="font-weight-bold">University Name</Content>
              <Content>2010 - 2014 | GPA 3.5</Content>
            </div>
            <div className="col-4 p-0">
              <TitleSmall>Under Graduate in Graphic Design</TitleSmall>
              <Content className="font-weight-bold">University Name</Content>
              <Content>2010 - 2014 | GPA 3.5</Content>
            </div>
            <div className="col-4 p-0">
              <TitleSmall>364683l in Multimedia</TitleSmall>
              <Content className="font-weight-bold">University Name</Content>
              <Content>2010 - 2014 | GPA 3.5</Content>
            </div>
          </div>
        </Experience>
      </Box>
      <div className="my-row">
        <div className="col-4 p-0">
          <Box className="mr-5">
            <Title>Skills</Title>
            <SkillsBox>
              <Span>Photoshop</Span>
              <ProgressBar
                completed={90}
                bgColor="#626db7"
                height="3px"
                isLabelVisible={false}
                baseBgColor="#EBF0F1"
                className="w-100"
              />
              <Span>90%</Span>
            </SkillsBox>
            <SkillsBox>
              <Span>Aftereffects</Span>
              <ProgressBar
                completed={80}
                bgColor="#626db7"
                height="3px"
                isLabelVisible={false}
                baseBgColor="#EBF0F1"
                className="w-100"
              />
              <Span>80%</Span>
            </SkillsBox>
            <SkillsBox>
              <Span>Illustrator</Span>
              <ProgressBar
                completed={75}
                bgColor="#626db7"
                height="3px"
                isLabelVisible={false}
                baseBgColor="#EBF0F1"
                className="w-100"
              />
              <Span>75%</Span>
            </SkillsBox>
            <SkillsBox>
              <Span>Lightroom</Span>
              <ProgressBar
                completed={50}
                bgColor="#626db7"
                height="3px"
                isLabelVisible={false}
                baseBgColor="#EBF0F1"
                className="w-100"
              />
              <Span>50%</Span>
            </SkillsBox>
            <SkillsBox>
              <Span>Indesign</Span>
              <ProgressBar
                completed={30}
                bgColor="#626db7"
                height="3px"
                isLabelVisible={false}
                baseBgColor="#EBF0F1"
                className="w-100"
              />
              <Span>30%</Span>
            </SkillsBox>
          </Box>
        </div>
        <div className="col-4 p-0">
          <Box className="mr-5">
            <Title>Hobbies</Title>
            <Hobbies>
              <HobbiesBox>
                <img src={images.basketball} alt="" />
                <Content className="font-weight-bold">basketball</Content>
              </HobbiesBox>
              <HobbiesBox>
                <img src={images.music} alt="" />
                <Content className="font-weight-bold">Music</Content>
              </HobbiesBox>
              <HobbiesBox>
                <img src={images.singing} alt="" />
                <Content className="font-weight-bold">Singing</Content>
              </HobbiesBox>
              <HobbiesBox>
                <img src={images.travel} alt="" />
                <Content className="font-weight-bold">Travel</Content>
              </HobbiesBox>
              <HobbiesBox>
                <img src={images.swimming} alt="" />
                <Content className="font-weight-bold">Swimming</Content>
              </HobbiesBox>
              <HobbiesBox>
                <img src={images.cycle} alt="" />
                <Content className="font-weight-bold">Cycling</Content>
              </HobbiesBox>
            </Hobbies>
          </Box>
        </div>
        <div className="col-4 p-0">
          <Box className="mr-5">
            <Title>References</Title>
            <Content className="font-weight-bold m-0">John Doe</Content>
            <Content className="font-weight-bold m-0">Designation</Content>
            <Content className="m-0">Creative Studio , USA</Content>
            <Content className="font-weight-bold m-0">
              Email: <Span>name@email.com</Span>
            </Content>
            <Content className="font-weight-bold">
              Phone: <Span>123456789</Span>
            </Content>
          </Box>
        </div>
      </div>
    </Container>
  );
};
