import address from "./address.png";
import dob from "./dob.png";
import mail from "./mail.png";
import name from "./name.png";
import phone from "./phone.png";
import website from "./website.png";
import basketball from "./basketball.png";
import cycle from "./cycle.png";
import music from "./music.png";
import singing from "./singing.png";
import swimming from "./swimming.png";
import travel from "./travel.png";

export default {
  address,
  dob,
  mail,
  name,
  phone,
  website,
  basketball,
  cycle,
  music,
  singing,
  swimming,
  travel,
};
