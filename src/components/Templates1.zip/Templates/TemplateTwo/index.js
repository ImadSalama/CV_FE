import React from "react";
import ReactDOM from "react-dom";
import styled from "styled-components";
import icons from "../TemplateOne/assets";
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

export default () => {
  const Container = styled.div`
    height: auto;
    width : 95%;
    margin-left: auto;
    margin-right: auto;
  `;

  

  const ProfileImage = styled.div`
    overflow: hidden;
    display: flex;
    justify-content: center;
    height:168px;
    width:168px;
    margin:0 auto;
    border:2px solid black;
    border-radius:50%;
  `;
 const ProfileDetail = styled.div`
    width: 55%;
    margin:10px auto;
    padding : 0 20px;
 `;

 const UserName = styled.h1`
    font-size : 51px;
    text-align : center;
    font-weight : 300;
 `;
 const SkillSet = styled.h5`
    font-size : 13px;
    text-align:center;
    color:#343240;
    letter-spacing : 3px;
    text-transform: uppercase;
 `;
const DetailBox = styled.div`
    margin:20px 0;
`;
const HeadingContent = styled.h3`
    font-size:17px;
    font-weight:bold;
    letter-spacing:2px;
    text-align:center;
    color: #343240;
    text-transform:uppercase;
`;
const HeadingDivider = styled.div`
    height:1px;
    width:100%;
    background:#343240;
    margin:20px 0;
`;
const ContentDetail = styled.p`
    font-size : 10px;
    font-weight : 500;
    text-align:center;
    color :#343240;
    letter-spacing: 2px;
    padding : 10px 0;
    line-height:18px;
`;
const ContentBox = styled.div`
    margin:50px 0 0;
`;
const InterestIcons = styled.div`
    display:flex;
    flex-wrap:wrap;
    justify-content : space-between;
    margin-bottom : 50px;
`;
const HeadingWithDivider = styled.div`
    // height:1px;
    // width:100%;
    // background-color:black;
    display : flex;
    align-items:center;
    justify-content:space-between;

`;
const PortfolioSec = styled.div`
    margin: 40px 0;
`;

const SkillBox = styled.div`
    height:77px;
    width:77px;
    border-radius:50%;
    border: 1px solid #343240;
    display:flex;
    align-items:center;
    justify-content:center;
`;

const EducationDetail = styled.div`
    display:flex;
    margin-left : 100px;
    
`;

const EducationYear = styled.div``;

const EducationDivider = styled.div`
    width:1px;
    background-color:black;
    margin-left:50px;
    position:relative;
    :before{
        content:"";
        height:10px;
        width:10px;
        background-color:black;
        position:absolute;
        border-radius:50%;
        left:-4px;
    }
`;

const EducationInst = styled.div`
    margin-left:50px;
`;
  return (
    <Container>
      <div className="my-row">
        <div className="col-4">
            <ProfileDetail>
                <DetailBox>
          <ProfileImage>
            <img src={icons.dp} />
          </ProfileImage>
          </DetailBox>
<DetailBox>
          <UserName>
              AMBER BRIS
          </UserName>
          <SkillSet>
              graphic designer
          </SkillSet>
          </DetailBox>
          <ContentBox>
        <HeadingContent>
            Profile
        </HeadingContent>
        <HeadingDivider></HeadingDivider>
        <ContentDetail>
        Make the most of your
introduction by writing
a short, snappy Lines
about yourself.
        </ContentDetail>
          </ContentBox>

        <ContentBox>
            <HeadingContent>
                Contact
            </HeadingContent>
            <HeadingDivider></HeadingDivider>
            <ContentDetail>
            +421-944-123-000<br/>
+421-944-000-419


            </ContentDetail>
            <ContentDetail>
            993 Carson St.<br/>
west New York, NJ 07093
            </ContentDetail>
            <ContentDetail>
            Your website@outlook.sk<br/>
example@gmall.com
            </ContentDetail>
        </ContentBox>
        <ContentBox>
            <HeadingContent>
                Interests
            </HeadingContent>
            <HeadingDivider></HeadingDivider>
            <InterestIcons>
                <img src={icons.tourism} />
                <img src={icons.traveling} />
            </InterestIcons>
            <InterestIcons>
                <img src={icons.video_games} />
                <img src={icons.aviation} />
            </InterestIcons>
            <InterestIcons>
                <img src={icons.books} />
                <img src={icons.djplaying} />
            </InterestIcons>
        </ContentBox>
          </ProfileDetail>
        </div>
        <div className="col-8">
            <PortfolioSec>
         <HeadingWithDivider>
            <HeadingContent className="text-left">
                About
            </HeadingContent>
            <HeadingDivider className="width-70"></HeadingDivider>
         </HeadingWithDivider>
         <ContentDetail className="width-70 text-left">
         I am Amber Bris a 25 year old Lead Visual Designer & Freelance
UI/UX Expert from New York. I loves everything that has to do
with App Design, IJI/UX, Graphic design, Packaging, Industrial
design and feel true devotion for typography. I have 4 years of
experience working as a designer and working with a studio
during studies..
         </ContentDetail>
         </PortfolioSec>
         <PortfolioSec>
         <HeadingWithDivider>
            <HeadingContent className="text-left">
                Education
            </HeadingContent>
            <HeadingDivider className="width-70"></HeadingDivider>
         </HeadingWithDivider>
         <PortfolioSec>
        <EducationDetail>
            <EducationYear>
                <p>2004 - 2009</p>
            </EducationYear>
            <EducationDivider></EducationDivider>
            <EducationInst>
                <h3>Degree Title</h3>
                <h5>University / School Name.</h5>
                <p>Write Your Text</p>
            </EducationInst>
        </EducationDetail>
        <EducationDetail>
            <EducationYear>
                <p>2004 - 2009</p>
            </EducationYear>
            <EducationDivider></EducationDivider>
            <EducationInst>
                <h3>Degree Title</h3>
                <h5>University / School Name.</h5>
                <p>Write Your Text</p>
            </EducationInst>
        </EducationDetail>
        <EducationDetail>
            <EducationYear>
                <p>2004 - 2009</p>
            </EducationYear>
            <EducationDivider></EducationDivider>
            <EducationInst>
                <h3>Degree Title</h3>
                <h5>University / School Name.</h5>
                <p>Write Your Text</p>
            </EducationInst>
        </EducationDetail>
        </PortfolioSec>
         </PortfolioSec>
         <PortfolioSec>
         <HeadingWithDivider>
            <HeadingContent className="text-left">
                Language Skills
            </HeadingContent>
            <HeadingDivider className="width-70"></HeadingDivider>
         </HeadingWithDivider>
         <ContentDetail className="width-70 text-left">
         It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. 
         </ContentDetail>
         <div className="my-row">
             <div className="col-3">
                  <CircularProgressbar styles={{root:{
                            height: 100,
                            width: 100,
                        },
                        path:{
                            stroke: "black",
                        },  
                        text:{
                            fontSize: 10
                        }
                        }} value={70} text="70%" />

                
                 <p>Lorem Ispom</p>
             </div>
             <div className="col-3">
             <CircularProgressbar styles={{root:{
                            height: 100,
                            width: 100,
                        },
                        path:{
                            stroke: "black",
                        },  
                        text:{
                            fontSize: 10
                        }
                        }} value={70} text="70%" />

                
                 <p>Lorem Ispom</p>
             </div>
             <div className="col-3">
             <CircularProgressbar styles={{root:{
                            height: 100,
                            width: 100,
                        },
                        path:{
                            stroke: "black",
                        },  
                        text:{
                            fontSize: 10
                        }
                        }} value={70} text="70%" />

                
                 <p>Lorem Ispom</p>
             </div>
             <div className="col-3">
             <CircularProgressbar styles={{root:{
                            height: 100,
                            width: 100,
                        },
                        path:{
                            stroke: "black",
                        },  
                        text:{
                            fontSize: 10
                        }
                        }} value={70} text="70%" />

                
                 <p>Lorem Ispom</p>
             </div>
         </div>
         </PortfolioSec>
         <PortfolioSec>
         <HeadingWithDivider>
            <HeadingContent className="text-left">
                Facts
            </HeadingContent>
            <HeadingDivider className="width-70"></HeadingDivider>
         </HeadingWithDivider>
         <ContentDetail className="width-70 text-left">
            <ul className="ml-3">
                <li>Owns a driver’s license</li>
                <li>Possibility to use own car</li>
                <li>5+ years pf wprk experience</li>
                <li>Has many hobbies (baseball, tennis, soccer, american football)</li>
                <li>Likes photographing and has over 5,000 Instagram followers</li>
                <li>Loves going to Disneyland with his family</li>
            </ul>
         </ContentDetail>
        
         </PortfolioSec>
         <PortfolioSec>
         <HeadingWithDivider>
            <HeadingContent className="text-left">
                Employment History
            </HeadingContent>
            <HeadingDivider className="width-70"></HeadingDivider>
         </HeadingWithDivider>
         <PortfolioSec>
        <EducationDetail>
            <EducationYear>
                <p>2004 - 2009</p>
            </EducationYear>
            <EducationDivider></EducationDivider>
            <EducationInst>
                <h3>Designation Title</h3>
                <h5>Company Name.</h5>
                <p>Write About Your Employment</p>
            </EducationInst>
        </EducationDetail>
        <EducationDetail>
            <EducationYear>
                <p>2004 - 2009</p>
            </EducationYear>
            <EducationDivider></EducationDivider>
            <EducationInst>
            <h3>Designation Title</h3>
                <h5>Company Name.</h5>
                <p>Write About Your Employment</p>
            </EducationInst>
        </EducationDetail>
       
        </PortfolioSec>
         </PortfolioSec>
       
        </div>
      </div>
    </Container>
  );
};

